#!/bin/bash

# Prints the message to standard output, showcasing how to display text in the terminal.
pip install lightgbm
pip install catboost
echo "This is a demonstration of executing a bash script."
